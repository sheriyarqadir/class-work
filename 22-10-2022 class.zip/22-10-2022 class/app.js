// ================ Questions Array ==================
// [
//     {
//       question: "Html Stands For ________________________________________________________________________________________________________________________________________________________________________________",
//       options: [
//         "Hyper Text Makeup Language",
//         "html",
//         "Case Cading Style Sheet",
//         "Hypertext markup language",
//       ],
//       correctAns: "Hypertext markup language",
//     },
//     {
//       question: "Css Stands For _______________________",
//       options: [
//         "Casecading Style Sheet",
//         "Java",
//         "Ram",
//         "Hypertext markup language",
//       ],
//       correctAns: "Casecading Style Sheet",
//     },
//     {
//       question: "Js Stands For _______________________",
//       options: ["Java Style", "Java Script", "Script", "Script Src"],
//       correctAns: "Java Script",
//     },
//     {
//       question: "Dom Stands For _______________________",
//       options: ["Document Object Model", "html", "Css", "Java"],
//       correctAns: "Document Object Model",
//     },
//     {
//       question: "Ram Stands For _______________________",
//       options: ["Read Only Memory", "Dom", "Random Acccess Memory", "For Pc"],
//       correctAns: "Random Acccess Memory",
//     },
//     {
//       question: "Rom Stands For _______________________",
//       options: [
//         "Hyper Text Markup Language",
//         "html",
//         "HTml",
//         "Read Only Memory",
//       ],
//       correctAns: "Read Only Memory",
//     },
//   ]

//   =============== Question Array Ends =======================



// var stdname = document.getElementById('sdtname');
// var fname = document.getElementById('fname');
// var rollno = document.getElementById('rollno');
// var tbody = document.getElementById('tb');
// var arr = [
//      std ={
//     name:"abc",
//     fathername: "abc father",
//     rollno:1
// },
//  std1 ={
//     name:"abcs",
//     fathername: "abc father",
//     rollno:1
// }]
// console.log(arr[0] );
// for (let i = 0; i < arr.length; i++) {
//     // tbody.innerHTML=  
//     stdname.innerHTML = arr[i].name;
//     fname.innerHTML = arr[i].fathername;
//     rollno.innerHTML = arr[i].rollno;


// }

var questionArray = [
    {
        question: "Html Stands For ______________________",
        options: [
            "Hyper Text Makeup Language",
            "html",
            "Case Cading Style Sheet",
            "Hypertext markup language",
        ],
        correctAns: "Hypertext markup language",
    },
    {
        question: "Css Stands For _______________________",
        options: [
            "Casecading Style Sheet",
            "Java",
            "Ram",
            "Hypertext markup language",
        ],
        correctAns: "Casecading Style Sheet",
    },
    {
        question: "Js Stands For _______________________",
        options: ["Java Style", "Java Script", "Script", "Script Src"],
        correctAns: "Java Script",
    },
    {
        question: "Dom Stands For _______________________",
        options: ["Document Object Model", "html", "Css", "Java"],
        correctAns: "Document Object Model",
    },
    {
        question: "Ram Stands For _______________________",
        options: ["Read Only Memory", "Dom", "Random Acccess Memory", "For Pc"],
        correctAns: "Random Acccess Memory",
    },
    {
        question: "Rom Stands For _______________________",
        options: [
            "Hyper Text Markup Language",
            "html",
            "HTml",
            "Read Only Memory",
        ],
        correctAns: "Read Only Memory",
    },
]

var question = document.getElementById('question');
var currentcount = document.getElementById('currentcount');
var totalcount = document.getElementById('totalcount');
var completeQuestion = document.getElementById('completeQuestion');
var allOption = document.getElementById('allOption');
var button = document.getElementById('button');


currentindex = 0;

function init() {

    var index = currentindex + 1;
    currentcount.innerHTML = index
    totalcount.innerHTML = questionArray.length;

    completeQuestion.innerHTML = questionArray[currentindex].question

    // Now for options we need loop
    // console.log(questionArray[currentindex].options);
    for (let i = 0; i < questionArray[currentindex].options.length; i++) {
        var options = questionArray[currentindex].options[i];
        // console.log(`${questionArray[currentindex].correctAns}`);
         allOption.innerHTML +=`<span class='options' id="allOption" onclick="marks('${options},${questionArray[currentindex].correctAns}')">
         ${options}</span>`;
         
        
        // console.log(options );
    }
}
init();

function next(){
    allOption.innerHTML = '';
    currentindex++
    init();
}
function previous(){
    allOption.innerHTML = '';
    currentindex--
    init();
}

function marks(userSelect,correctAnswer){
    // console.log(userSelect);
    console.log(correctAnswer);
    if(userSelect == correctAnswer){
        console.log("ohh yeah");
    }
}